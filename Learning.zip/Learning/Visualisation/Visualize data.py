# Databricks notebook source
# First, make sure the Excel package is installed:
# On Databricks: Go to "Libraries" → "Install New" → Maven → paste:
# com.crealytics:spark-excel_2.12:0.13.5

# Updated code to read Excel (.xlsx) using spark-excel
file_location = "/FileStore/tables/googlestore.xlsx"

df = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("dataAddress", "'Sheet1'!A1") \
    .load(file_location)

display(df)


# COMMAND ----------

from pyspark.sql.functions import col

# Function to clean column names by replacing invalid characters
def clean_column_names(df):
    for column in df.columns:
        # Replace invalid characters with an underscore (_)
        new_name = column.replace(" ", "_").replace(",", "_").replace(";", "_") \
                          .replace("{", "_").replace("}", "_").replace("(", "_") \
                          .replace(")", "_").replace("\n", "_").replace("\t", "_") \
                          .replace("=", "_")
        # Rename the column
        df = df.withColumnRenamed(column, new_name)
    return df

# Clean the column names
df_cleaned = clean_column_names(df)

# Save the DataFrame as a table with cleaned column names
df_cleaned.write.saveAsTable("playStore")


# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from playStore

# COMMAND ----------

# MAGIC %sql
# MAGIC Select Category,Count(Installs) from playstore
# MAGIC Group by Category

# COMMAND ----------

# MAGIC %sql
# MAGIC Select Genres, SUM(Reviews) from playstore
# MAGIC Group By Genres

# COMMAND ----------

# MAGIC %sql
# MAGIC Select  APP, SUm(Price) from playstore
# MAGIC Group BY APP 
# MAGIC ORDER BY APP DESC 

# COMMAND ----------

